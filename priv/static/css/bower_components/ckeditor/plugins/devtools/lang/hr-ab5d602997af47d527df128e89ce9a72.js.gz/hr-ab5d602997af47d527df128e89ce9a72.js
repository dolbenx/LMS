﻿/*
 Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("devtools","hr",{title:"Informacije elementa",dialogName:"Naziv prozora za dijalog",tabName:"Naziv kartice",elementId:"ID elementa",elementType:"Vrsta elementa"});