﻿/*
 Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("uicolor","da",{title:"Brugerflade på farvevælger",options:"Color Options",highlight:"Highlight",selected:"Selected Color",predefined:"Prædefinerede farveskemaer",config:"Indsæt denne streng i din config.js fil"});