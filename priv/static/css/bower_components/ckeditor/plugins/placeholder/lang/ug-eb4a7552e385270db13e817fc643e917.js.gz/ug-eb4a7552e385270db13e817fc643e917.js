﻿/*
 Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("placeholder","ug",{title:"ئورۇن بەلگە خاسلىقى",toolbar:"ئورۇن بەلگە قۇر",name:"ئورۇن بەلگە ئىسمى",invalidName:"The placeholder can not be empty and can not contain any of following characters: [, ], \x3c, \x3e",pathName:"placeholder"});