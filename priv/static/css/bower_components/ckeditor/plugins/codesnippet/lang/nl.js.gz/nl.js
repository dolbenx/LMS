﻿/*
 Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("codesnippet","nl",{button:"Stuk code invoegen",codeContents:"Code",emptySnippetError:"Een stuk code kan niet leeg zijn.",language:"Taal",title:"Stuk code",pathName:"stuk code"});