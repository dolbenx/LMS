defmodule SavingsWeb.TransactionController do
  use SavingsWeb, :controller

  def index(conn, _params) do
    render(conn, "index.html")
  end

  def all_transactions(conn, _params) do
    customer = Savings.Accounts.get_all_customer_details()
    render(conn, "all_transactions.html", customer: customer)
  end

  def fixed_deposits(conn, _params) do
    customer = Savings.Accounts.get_all_customer_details()
    render(conn, "fixed_deposits.html", customer: customer)
  end

  def full_withdraws(conn, _params) do
    customer = Savings.Accounts.get_all_customer_details()
    render(conn, "full_withdraws.html", customer: customer)
  end

  def partial_withdraws(conn, _params) do
    customer = Savings.Accounts.get_all_customer_details()
    render(conn, "partial_withdraws.html", customer: customer)
  end
end
